﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Chat")]
    public class Chat
    {
        [Key]
        public int ChatId { get; set; }
        public int ClienteId { get; set; }
        public int RestauranteId { get; set; }
        public string Mensaje { get; set; }
        public DateTime Fecha { get; set; }

    }
}
