﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Cliente")]
    public class Cliente
    {
        [Key]
        public int UsuarioId { get; set; }

    }
}
