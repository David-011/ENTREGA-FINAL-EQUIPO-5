﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.DetallePedido")]
    public class DetallePedido
    {
        [Key]
        public int DetalleId { get; set; }
        public int PedidoId { get; set; }
        public int PlatoId { get; set; }
        public int Cantidad { get; set; }
        public decimal Subtotal { get; set; }

    }
}
