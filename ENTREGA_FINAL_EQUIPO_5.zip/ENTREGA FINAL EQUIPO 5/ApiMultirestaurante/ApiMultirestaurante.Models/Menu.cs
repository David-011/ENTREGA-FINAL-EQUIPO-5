﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Menu")]
    public class Menu
    {
        [Key]
        public int MenuId { get; set; }
        public int UsuarioId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaActualizacion { get; set; }
    }
}
