﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Pedido")]
    public class Pedido
    {
        [Key]
        public int PedidoId { get; set; }
        public int ClienteId { get; set; }
        public int RestauranteId { get; set; }
        public DateTime FechaPedido { get; set; }
        public string Estado { get; set; }
        public string DireccionEnvio { get; set; }
    }
}
