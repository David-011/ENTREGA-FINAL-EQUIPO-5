﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Plato")]
    public class Plato
    {
        [Key]
        public int PlatoId { get; set; }
        public int MenuId { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public decimal Precio { get; set; }
    }
}
