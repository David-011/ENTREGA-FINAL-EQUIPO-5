﻿using Dapper.Contrib.Extensions;
using System;

namespace ApiMultirestaurante.Models
{
    [Table("dbo.Usuario")]
    public class Usuario
    {
        [Key]
        public int UsuarioId { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public string Contraseña { get; set; }
        public string Telefono { get; set; }
        public string TipoUsuario { get; set; }

    }
}
