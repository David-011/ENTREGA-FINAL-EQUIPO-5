﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class ChatQueries : IChatQueries
    {
        private readonly IDbConnection _db;

        public ChatQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<List<Chat>> GetAll()
        {
            var rs = await _db.QueryAsync<Chat>("SELECT * FROM Chat ORDER BY Fecha");
            return rs.ToList();
        }

        public async Task<Chat> GetById(int id)
        {
            return await _db.QueryFirstOrDefaultAsync<Chat>(
                "SELECT * FROM Chat WHERE ChatId = @id", new { id });
        }

        public async Task<List<Chat>> GetByCliente(int clienteId)
        {
            var rs = await _db.QueryAsync<Chat>(
                "SELECT * FROM Chat WHERE ClienteId = @clienteId ORDER BY Fecha",
                new { clienteId });
            return rs.ToList();
        }

        public async Task<List<Chat>> GetByRestaurante(int restauranteId)
        {
            var rs = await _db.QueryAsync<Chat>(
                "SELECT * FROM Chat WHERE RestauranteId = @restauranteId ORDER BY Fecha",
                new { restauranteId });
            return rs.ToList();
        }

        public async Task<List<Chat>> GetByClienteYRestaurante(int clienteId, int restauranteId)
        {
            var rs = await _db.QueryAsync<Chat>(
                "SELECT * FROM Chat WHERE ClienteId = @clienteId AND RestauranteId = @restauranteId ORDER BY Fecha",
                new { clienteId, restauranteId });
            return rs.ToList();
        }
    }
}
