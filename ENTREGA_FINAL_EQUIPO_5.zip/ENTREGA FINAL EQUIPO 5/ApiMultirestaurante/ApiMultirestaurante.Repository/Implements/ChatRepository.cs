﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class ChatRepository : IChatRepository
    {
        private readonly IDbConnection _db;

        public ChatRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<Chat> Add(Chat entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.ChatId = (int)rs;
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(Chat entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var chat = await _db.GetAsync<Chat>(id);
                if (chat == null)
                    return false;

                return await _db.DeleteAsync(chat);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
