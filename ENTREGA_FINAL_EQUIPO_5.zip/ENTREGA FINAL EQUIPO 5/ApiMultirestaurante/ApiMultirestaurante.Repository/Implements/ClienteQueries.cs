﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class ClienteQueries : IClienteQueries
    {
        private readonly IDbConnection _db;

        public ClienteQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Cliente>> GetAll()
        {
            try
            {
                var rs = await _db.QueryAsync<Cliente>("SELECT * FROM Cliente");
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Cliente> GetById(int id)
        {
            try
            {
                var rs = await _db.QueryFirstOrDefaultAsync<Cliente>(
                    "SELECT * FROM Cliente WHERE UsuarioId = @id",
                    new { id });
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<List<Cliente>> GetByRestaurante(int restauranteId)
        {
            try
            {
                var rs = await _db.QueryAsync<Cliente>(
                    "SELECT * FROM Cliente WHERE RestauranteId = @restauranteId",
                    new { restauranteId });

                return rs.ToList(); 
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
