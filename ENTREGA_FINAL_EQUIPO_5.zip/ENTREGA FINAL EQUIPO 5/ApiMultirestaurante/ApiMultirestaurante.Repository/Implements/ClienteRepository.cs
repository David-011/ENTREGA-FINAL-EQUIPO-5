﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class ClienteRepository : IClienteRepository
    {
        private readonly IDbConnection _db;

        public ClienteRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<Cliente> Add(Cliente entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.UsuarioId = (int)rs;
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(Cliente entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var cliente = await _db.GetAsync<Cliente>(id);
                if (cliente == null)
                    return false;

                return await _db.DeleteAsync(cliente);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}