﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class DetallePedidoQueries : IDetallePedidoQueries
    {
        private readonly IDbConnection _db;

        public DetallePedidoQueries(IDbConnection db)
        {
            _db = db;
        }

        public async Task<IEnumerable<DetallePedido>> GetAll()
        {
            var query = "SELECT * FROM dbo.DetallePedido";
            var rs = await _db.QueryAsync<DetallePedido>(query);
            return rs.ToList();
        }

        public async Task<DetallePedido> GetById(int id)
        {
            var query = "SELECT * FROM dbo.DetallePedido WHERE DetalleId = @id";
            var rs = await _db.QueryFirstOrDefaultAsync<DetallePedido>(query, new { id });
            return rs;
        }

        public async Task<IEnumerable<DetallePedido>> GetByPedidoId(int pedidoId)
        {
            var query = "SELECT * FROM dbo.DetallePedido WHERE PedidoId = @pedidoId";
            var rs = await _db.QueryAsync<DetallePedido>(query, new { pedidoId });
            return rs.ToList();
        }
    }
}
