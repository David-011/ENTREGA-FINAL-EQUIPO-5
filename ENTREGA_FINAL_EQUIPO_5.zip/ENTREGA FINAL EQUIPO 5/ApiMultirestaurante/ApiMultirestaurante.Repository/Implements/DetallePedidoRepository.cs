﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class DetallePedidoRepository : IDetallePedidoRepository
    {
        private readonly IDbConnection _db;

        public DetallePedidoRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<DetallePedido> Add(DetallePedido entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.DetalleId = (int)rs;
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(DetallePedido entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var detalle = await _db.GetAsync<DetallePedido>(id);
                if (detalle == null)
                    return false;

                return await _db.DeleteAsync(detalle);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
