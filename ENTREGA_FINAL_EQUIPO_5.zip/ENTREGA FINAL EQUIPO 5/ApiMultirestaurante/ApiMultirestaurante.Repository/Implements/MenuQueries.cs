﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class MenuQueries : IMenuQueries
    {
        private readonly IDbConnection _db;

        public MenuQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Menu>> GetAll()
        {
            try
            {
                var rs = await _db.QueryAsync<Menu>("SELECT * FROM Menu");
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Menu> GetById(int id)
        {
            try
            {
                var rs = await _db.QueryFirstOrDefaultAsync<Menu>(
                    "SELECT * FROM Menu WHERE MenuId = @id",
                    new { id });
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}