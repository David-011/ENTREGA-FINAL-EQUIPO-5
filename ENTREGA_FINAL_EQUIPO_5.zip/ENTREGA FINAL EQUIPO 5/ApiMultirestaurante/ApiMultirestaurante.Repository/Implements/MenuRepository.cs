﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Implements;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class MenuRepository : IMenuRepository
    {
        private readonly IDbConnection _db;

        public MenuRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<Menu> Add(Menu entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.MenuId = (int)rs;
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(Menu entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var menu = await _db.GetAsync<Menu>(id);
                if (menu == null)
                    return false;

                return await _db.DeleteAsync(menu);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

