﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class PedidoQueries : IPedidoQueries
    {
        private readonly IDbConnection _db;

        public PedidoQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Pedido>> GetAll()
        {
            try
            {
                var rs = await _db.QueryAsync<Pedido>("SELECT * FROM Pedido");
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Pedido> GetById(int id)
        {
            try
            {
                var rs = await _db.QueryFirstOrDefaultAsync<Pedido>(
                    "SELECT * FROM Pedido WHERE PedidoId = @id",
                    new { id });
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}