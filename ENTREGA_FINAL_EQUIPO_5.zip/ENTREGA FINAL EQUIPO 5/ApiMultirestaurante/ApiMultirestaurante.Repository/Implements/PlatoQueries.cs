﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class PlatoQueries : IPlatoQueries
    {
        private readonly IDbConnection _db;

        public PlatoQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Plato>> GetAll()
        {
            try
            {
                var rs = await _db.QueryAsync<Plato>("SELECT * FROM Plato");
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Plato> GetById(int id)
        {
            try
            {
                var rs = await _db.QueryFirstOrDefaultAsync<Plato>(
                    "SELECT * FROM Plato WHERE PlatoId = @id",
                    new { id });
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
