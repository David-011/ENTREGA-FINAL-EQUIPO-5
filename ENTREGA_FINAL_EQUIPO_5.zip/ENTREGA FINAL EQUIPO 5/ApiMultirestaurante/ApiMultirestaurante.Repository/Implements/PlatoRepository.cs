﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class PlatoRepository : IPlatoRepository
    {
        private readonly IDbConnection _db;

        public PlatoRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<Plato> Add(Plato entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.PlatoId = rs;
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(Plato entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var plato = await _db.GetAsync<Plato>(id);
                if (plato == null)
                    return false;

                return await _db.DeleteAsync(plato);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
