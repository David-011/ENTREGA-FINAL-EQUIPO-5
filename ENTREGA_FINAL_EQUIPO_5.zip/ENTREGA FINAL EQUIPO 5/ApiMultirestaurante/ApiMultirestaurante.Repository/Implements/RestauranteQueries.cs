﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class RestauranteQueries : IRestauranteQueries
    {
        private readonly IDbConnection _db;

        public RestauranteQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Restaurante>> GetAll()
        {
            try
            {
                var rs = await _db.QueryAsync<Restaurante>("SELECT * FROM Restaurante");
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Restaurante> GetById(int id)
        {
            try
            {
                var rs = await _db.QueryFirstOrDefaultAsync<Restaurante>(
                    "SELECT * FROM Restaurante WHERE UsuarioId = @id",
                    new { id });
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}


