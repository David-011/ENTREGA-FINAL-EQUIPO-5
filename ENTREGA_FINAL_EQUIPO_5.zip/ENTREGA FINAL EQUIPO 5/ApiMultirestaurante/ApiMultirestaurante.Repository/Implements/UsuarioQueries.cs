﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class UsuarioQueries : IUsuarioQueries
    {
        private readonly IDbConnection _db;

        public UsuarioQueries(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<IEnumerable<Usuario>> GetAll()
        {
            try
            {
                var rs = "SELECT * FROM Usuario";
                return await _db.QueryAsync<Usuario>(rs);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Usuario> GetById(int id)
        {
            try
            {
                var rs = "SELECT * FROM Usuario WHERE UsuarioId = @Id";
                return await _db.QueryFirstOrDefaultAsync<Usuario>(rs, new { Id = id });
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<Usuario>> GetByTipoUsuario(string tipo)
        {
            try
            {
                var rs = "SELECT * FROM Usuario WHERE TipoUsuario = @Tipo";
                return await _db.QueryAsync<Usuario>(rs, new { Tipo = tipo });
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Usuario> GetByEmail(string email)
        {
            try
            {
                var rs = "SELECT * FROM Usuario WHERE Email = @Email";
                return await _db.QueryFirstOrDefaultAsync<Usuario>(rs, new { Email = email });
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
