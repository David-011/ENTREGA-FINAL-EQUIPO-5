﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Implements
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly IDbConnection _db;

        public UsuarioRepository(IDbConnection db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public async Task<Usuario> Add(Usuario entity)
        {
            try
            {
                var rs = await _db.InsertAsync(entity);
                entity.UsuarioId = rs; 
                return entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Usuario> GetById(int id)
        {
            try
            {
                return await _db.GetAsync<Usuario>(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Update(Usuario entity)
        {
            try
            {
                return await _db.UpdateAsync(entity);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Delete(int id)
        {
            try
            {
                var rs = await _db.GetAsync<Usuario>(id);
                if (rs == null) return false;

                return await _db.DeleteAsync(rs);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

