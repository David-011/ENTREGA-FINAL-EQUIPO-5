﻿using ApiMultirestaurante.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Chat.
    /// </summary>
    public interface IChatQueries
    {
        /// <summary>
        /// Obtiene todos los chats registrados.
        /// </summary>
        /// <returns>Una lista de todos los chats.</returns>
        Task<List<Chat>> GetAll();

        /// <summary>
        /// Obtiene un chat por su ID.
        /// </summary>
        /// <param name="id">ID del chat a buscar.</param>
        /// <returns>El chat correspondiente al ID, o null si no existe.</returns>
        Task<Chat> GetById(int id);

        /// <summary>
        /// Obtiene todos los chats asociados a un cliente específico.
        /// </summary>
        /// <param name="clienteId">ID del cliente cuyos chats se desean obtener.</param>
        /// <returns>Una lista de chats del cliente especificado.</returns>
        Task<List<Chat>> GetByCliente(int clienteId);

        /// <summary>
        /// Obtiene todos los chats asociados a un restaurante específico.
        /// </summary>
        /// <param name="restauranteId">ID del restaurante cuyos chats se desean obtener.</param>
        /// <returns>Una lista de chats del restaurante especificado.</returns>
        Task<List<Chat>> GetByRestaurante(int restauranteId);

        /// <summary>
        /// Obtiene todos los chats entre un cliente y un restaurante específicos.
        /// </summary>
        /// <param name="clienteId">ID del cliente.</param>
        /// <param name="restauranteId">ID del restaurante.</param>
        /// <returns>Una lista de chats entre el cliente y el restaurante especificados.</returns>
        Task<List<Chat>> GetByClienteYRestaurante(int clienteId, int restauranteId);
    }
}
