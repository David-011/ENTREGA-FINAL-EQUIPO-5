﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Chat.
    /// </summary>
    public interface IChatRepository
    {
        /// <summary>
        /// Agrega un nuevo chat a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Chat a agregar.</param>
        /// <returns>El chat agregado con su ID generado.</returns>
        Task<Chat> Add(Chat entity);

        /// <summary>
        /// Actualiza los datos de un chat existente.
        /// </summary>
        /// <param name="entity">Chat con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Chat entity);

        /// <summary>
        /// Elimina un chat por su ID.
        /// </summary>
        /// <param name="id">ID del chat a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
