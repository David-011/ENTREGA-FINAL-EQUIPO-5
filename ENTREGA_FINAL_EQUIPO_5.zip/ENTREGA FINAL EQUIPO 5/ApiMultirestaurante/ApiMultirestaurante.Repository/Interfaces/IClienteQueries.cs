﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Cliente.
    /// </summary>
    public interface IClienteQueries
    {
        /// <summary>
        /// Obtiene todos los clientes registrados.
        /// </summary>
        /// <returns>Una colección de todos los clientes.</returns>
        Task<IEnumerable<Cliente>> GetAll();

        /// <summary>
        /// Obtiene un cliente por su ID.
        /// </summary>
        /// <param name="id">ID del cliente a buscar.</param>
        /// <returns>El cliente correspondiente al ID, o null si no existe.</returns>
        Task<Cliente> GetById(int id);

        /// <summary>
        /// Obtiene todos los clientes asociados a un restaurante específico.
        /// </summary>
        /// <param name="restauranteId">ID del restaurante cuyos clientes se desean obtener.</param>
        /// <returns>Una lista de clientes asociados al restaurante especificado.</returns>
        Task<List<Cliente>> GetByRestaurante(int restauranteId);
    }
}
