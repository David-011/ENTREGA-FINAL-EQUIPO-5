﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Cliente.
    /// </summary>
    public interface IClienteRepository
    {
        /// <summary>
        /// Agrega un nuevo cliente a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Cliente a agregar.</param>
        /// <returns>El cliente agregado con su ID generado.</returns>
        Task<Cliente> Add(Cliente entity);

        /// <summary>
        /// Actualiza los datos de un cliente existente.
        /// </summary>
        /// <param name="entity">Cliente con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Cliente entity);

        /// <summary>
        /// Elimina un cliente por su ID.
        /// </summary>
        /// <param name="id">ID del cliente a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
