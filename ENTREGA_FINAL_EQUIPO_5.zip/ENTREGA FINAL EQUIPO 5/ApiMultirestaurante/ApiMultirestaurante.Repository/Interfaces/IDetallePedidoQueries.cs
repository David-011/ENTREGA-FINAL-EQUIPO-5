﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad DetallePedido.
    /// </summary>
    public interface IDetallePedidoQueries
    {
        /// <summary>
        /// Obtiene todos los detalles de pedido registrados.
        /// </summary>
        /// <returns>Una colección de todos los detalles de pedido.</returns>
        Task<IEnumerable<DetallePedido>> GetAll();

        /// <summary>
        /// Obtiene un detalle de pedido por su ID.
        /// </summary>
        /// <param name="id">ID del detalle de pedido a buscar.</param>
        /// <returns>El detalle de pedido correspondiente al ID, o null si no existe.</returns>
        Task<DetallePedido> GetById(int id);

        /// <summary>
        /// Obtiene todos los detalles de pedido asociados a un pedido específico.
        /// </summary>
        /// <param name="pedidoId">ID del pedido cuyos detalles se desean obtener.</param>
        /// <returns>Una colección de detalles de pedido asociados al pedido especificado.</returns>
        Task<IEnumerable<DetallePedido>> GetByPedidoId(int pedidoId);
    }
}
