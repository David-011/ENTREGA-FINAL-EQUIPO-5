﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad DetallePedido.
    /// </summary>
    public interface IDetallePedidoRepository
    {
        /// <summary>
        /// Agrega un nuevo detalle de pedido a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto DetallePedido a agregar.</param>
        /// <returns>El detalle de pedido agregado con su ID generado.</returns>
        Task<DetallePedido> Add(DetallePedido entity);

        /// <summary>
        /// Actualiza los datos de un detalle de pedido existente.
        /// </summary>
        /// <param name="entity">DetallePedido con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(DetallePedido entity);

        /// <summary>
        /// Elimina un detalle de pedido por su ID.
        /// </summary>
        /// <param name="id">ID del detalle de pedido a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
