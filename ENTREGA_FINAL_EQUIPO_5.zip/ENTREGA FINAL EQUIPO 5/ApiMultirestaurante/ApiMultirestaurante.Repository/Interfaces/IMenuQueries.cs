﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Menu.
    /// </summary>
    public interface IMenuQueries
    {
        /// <summary>
        /// Obtiene todos los menús registrados.
        /// </summary>
        /// <returns>Una colección de todos los menús.</returns>
        Task<IEnumerable<Menu>> GetAll();

        /// <summary>
        /// Obtiene un menú por su ID.
        /// </summary>
        /// <param name="id">ID del menú a buscar.</param>
        /// <returns>El menú correspondiente al ID, o null si no existe.</returns>
        Task<Menu> GetById(int id);
    }
}
