﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Menu.
    /// </summary>
    public interface IMenuRepository
    {
        /// <summary>
        /// Agrega un nuevo menú a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Menu a agregar.</param>
        /// <returns>El menú agregado con su ID generado.</returns>
        Task<Menu> Add(Menu entity);

        /// <summary>
        /// Actualiza los datos de un menú existente.
        /// </summary>
        /// <param name="entity">Menú con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Menu entity);

        /// <summary>
        /// Elimina un menú por su ID.
        /// </summary>
        /// <param name="id">ID del menú a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
