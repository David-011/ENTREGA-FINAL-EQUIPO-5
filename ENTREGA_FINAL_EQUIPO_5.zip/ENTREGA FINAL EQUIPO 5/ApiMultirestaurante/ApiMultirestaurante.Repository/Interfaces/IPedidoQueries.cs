﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Pedido.
    /// </summary>
    public interface IPedidoQueries
    {
        /// <summary>
        /// Obtiene todos los pedidos registrados.
        /// </summary>
        /// <returns>Una colección de todos los pedidos.</returns>
        Task<IEnumerable<Pedido>> GetAll();

        /// <summary>
        /// Obtiene un pedido por su ID.
        /// </summary>
        /// <param name="id">ID del pedido a buscar.</param>
        /// <returns>El pedido correspondiente al ID, o null si no existe.</returns>
        Task<Pedido> GetById(int id);
    }
}
