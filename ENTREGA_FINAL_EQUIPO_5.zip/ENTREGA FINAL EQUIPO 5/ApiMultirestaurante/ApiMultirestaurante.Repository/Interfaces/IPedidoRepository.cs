﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Pedido.
    /// </summary>
    public interface IPedidoRepository
    {
        /// <summary>
        /// Agrega un nuevo pedido a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Pedido a agregar.</param>
        /// <returns>El pedido agregado con su ID generado.</returns>
        Task<Pedido> Add(Pedido entity);

        /// <summary>
        /// Actualiza los datos de un pedido existente.
        /// </summary>
        /// <param name="entity">Pedido con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Pedido entity);

        /// <summary>
        /// Elimina un pedido por su ID.
        /// </summary>
        /// <param name="id">ID del pedido a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
