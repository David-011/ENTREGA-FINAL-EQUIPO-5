﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Plato.
    /// </summary>
    public interface IPlatoQueries
    {
        /// <summary>
        /// Obtiene todos los platos registrados.
        /// </summary>
        /// <returns>Una colección de todos los platos.</returns>
        Task<IEnumerable<Plato>> GetAll();

        /// <summary>
        /// Obtiene un plato por su ID.
        /// </summary>
        /// <param name="id">ID del plato a buscar.</param>
        /// <returns>El plato correspondiente al ID, o null si no existe.</returns>
        Task<Plato> GetById(int id);
    }
}
