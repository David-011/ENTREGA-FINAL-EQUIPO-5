﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Plato.
    /// </summary>
    public interface IPlatoRepository
    {
        /// <summary>
        /// Agrega un nuevo plato a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Plato a agregar.</param>
        /// <returns>El plato agregado con su ID generado.</returns>
        Task<Plato> Add(Plato entity);

        /// <summary>
        /// Actualiza los datos de un plato existente.
        /// </summary>
        /// <param name="entity">Plato con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Plato entity);

        /// <summary>
        /// Elimina un plato por su ID.
        /// </summary>
        /// <param name="id">ID del plato a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
