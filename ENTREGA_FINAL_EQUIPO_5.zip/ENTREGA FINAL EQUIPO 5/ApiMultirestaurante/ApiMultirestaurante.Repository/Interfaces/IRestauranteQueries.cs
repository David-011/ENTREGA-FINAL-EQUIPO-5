﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Restaurante.
    /// </summary>
    public interface IRestauranteQueries
    {
        /// <summary>
        /// Obtiene todos los restaurantes registrados.
        /// </summary>
        /// <returns>Una colección de todos los restaurantes.</returns>
        Task<IEnumerable<Restaurante>> GetAll();

        /// <summary>
        /// Obtiene un restaurante por su ID.
        /// </summary>
        /// <param name="id">ID del restaurante a buscar.</param>
        /// <returns>El restaurante correspondiente al ID, o null si no existe.</returns>
        Task<Restaurante> GetById(int id);
    }
}
