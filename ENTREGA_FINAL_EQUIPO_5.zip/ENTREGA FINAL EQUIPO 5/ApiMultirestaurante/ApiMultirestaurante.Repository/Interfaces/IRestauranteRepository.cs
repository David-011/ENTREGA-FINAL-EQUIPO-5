﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de acceso a datos para la entidad Restaurante.
    /// </summary>
    public interface IRestauranteRepository
    {
        /// <summary>
        /// Agrega un nuevo restaurante a la base de datos.
        /// </summary>
        /// <param name="entity">Objeto Restaurante a agregar.</param>
        /// <returns>El restaurante agregado con su ID generado.</returns>
        Task<Restaurante> Add(Restaurante entity);

        /// <summary>
        /// Actualiza los datos de un restaurante existente.
        /// </summary>
        /// <param name="entity">Restaurante con los datos actualizados.</param>
        /// <returns>true si la actualización fue exitosa; de lo contrario, false.</returns>
        Task<bool> Update(Restaurante entity);

        /// <summary>
        /// Elimina un restaurante por su ID.
        /// </summary>
        /// <param name="id">ID del restaurante a eliminar.</param>
        /// <returns>true si la eliminación fue exitosa; de lo contrario, false.</returns>
        Task<bool> Delete(int id);
    }
}
