﻿using ApiMultirestaurante.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Repository.Interfaces
{
    /// <summary>
    /// Define los métodos de consulta para la entidad Usuario.
    /// </summary>
    public interface IUsuarioQueries
    {
        /// <summary>
        /// Obtiene todos los usuarios registrados.
        /// </summary>
        /// <returns>Una colección de todos los usuarios.</returns>
        Task<IEnumerable<Usuario>> GetAll();

        /// <summary>
        /// Obtiene un usuario por su ID.
        /// </summary>
        /// <param name="id">ID del usuario a buscar.</param>
        /// <returns>El usuario correspondiente al ID, o null si no existe.</returns>
        Task<Usuario> GetById(int id);

        /// <summary>
        /// Obtiene los usuarios según su tipo (por ejemplo, "Cliente" o "Restaurante").
        /// </summary>
        /// <param name="tipo">Tipo de usuario a buscar.</param>
        /// <returns>Una colección de usuarios que coinciden con el tipo especificado.</returns>
        Task<IEnumerable<Usuario>> GetByTipoUsuario(string tipo);

        /// <summary>
        /// Obtiene un usuario por su correo electrónico.
        /// </summary>
        /// <param name="email">Correo electrónico del usuario.</param>
        /// <returns>El usuario correspondiente al correo, o null si no existe.</returns>
        Task<Usuario> GetByEmail(string email);
    }
}
