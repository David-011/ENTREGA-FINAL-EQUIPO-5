﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Chat.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ChatController : ControllerBase
    {
        private readonly IChatQueries _chatQueries;
        private readonly IChatRepository _chatRepository;

        /// <summary>
        /// Constructor del controlador ChatController.
        /// </summary>
        /// <param name="chatQueries">Repositorio para consultas de Chat.</param>
        /// <param name="chatRepository">Repositorio para operaciones de persistencia de Chat.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public ChatController(IChatQueries chatQueries, IChatRepository chatRepository)
        {
            _chatQueries = chatQueries ?? throw new ArgumentNullException(nameof(chatQueries));
            _chatRepository = chatRepository ?? throw new ArgumentNullException(nameof(chatRepository));
        }

        /// <summary>
        /// Obtiene todos los chats registrados.
        /// </summary>
        /// <returns>Lista de chats.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _chatQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un chat por su ID.
        /// </summary>
        /// <param name="id">ID del chat a buscar.</param>
        /// <returns>Chat correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _chatQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un chat con ID {id}");
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene todos los chats de un cliente específico.
        /// </summary>
        /// <param name="clienteId">ID del cliente.</param>
        /// <returns>Lista de chats del cliente.</returns>
        [HttpGet("cliente/{clienteId}")]
        public async Task<IActionResult> ObtenerPorCliente(int clienteId)
        {
            try
            {
                var rs = await _chatQueries.GetByCliente(clienteId);
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene todos los chats de un restaurante específico.
        /// </summary>
        /// <param name="restauranteId">ID del restaurante.</param>
        /// <returns>Lista de chats del restaurante.</returns>
        [HttpGet("restaurante/{restauranteId}")]
        public async Task<IActionResult> ObtenerPorRestaurante(int restauranteId)
        {
            try
            {
                var rs = await _chatQueries.GetByRestaurante(restauranteId);
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene los chats de un cliente específico con un restaurante específico.
        /// </summary>
        /// <param name="clienteId">ID del cliente.</param>
        /// <param name="restauranteId">ID del restaurante.</param>
        /// <returns>Lista de chats o NotFound si no hay mensajes.</returns>
        [HttpGet("{clienteId}/{restauranteId}")]
        public async Task<IActionResult> ObtenerPorClienteYRestaurante(int clienteId, int restauranteId)
        {
            try
            {
                var rs = await _chatQueries.GetByClienteYRestaurante(clienteId, restauranteId);
                if (rs == null || rs.Count == 0)
                    return NotFound("No hay mensajes para este chat.");
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo mensaje al chat.
        /// </summary>
        /// <param name="chat">Objeto Chat a agregar.</param>
        /// <returns>Chat agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Chat chat)
        {
            try
            {
                chat.Fecha = DateTime.Now;
                var rs = await _chatRepository.Add(chat);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.ChatId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar chat: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un mensaje de chat existente.
        /// </summary>
        /// <param name="chat">Objeto Chat con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el chat.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Chat chat)
        {
            try
            {
                var rs = await _chatRepository.Update(chat);
                if (!rs)
                    return NotFound($"No se encontró el chat con ID {chat.ChatId}");
                return Ok("Chat actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar chat: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un chat por su ID.
        /// </summary>
        /// <param name="id">ID del chat a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el chat.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _chatRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el chat con ID {id}");
                return Ok("Chat eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar chat: {ex.Message}");
            }
        }
    }
}
