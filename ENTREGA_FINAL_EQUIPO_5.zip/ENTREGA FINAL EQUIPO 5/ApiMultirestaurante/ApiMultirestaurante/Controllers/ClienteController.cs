﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Cliente.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IClienteQueries _clienteQueries;
        private readonly IClienteRepository _clienteRepository;

        /// <summary>
        /// Constructor del controlador ClienteController.
        /// </summary>
        /// <param name="clienteQueries">Repositorio para consultas de Cliente.</param>
        /// <param name="clienteRepository">Repositorio para operaciones de persistencia de Cliente.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public ClienteController(IClienteQueries clienteQueries, IClienteRepository clienteRepository)
        {
            _clienteQueries = clienteQueries ?? throw new ArgumentNullException(nameof(clienteQueries));
            _clienteRepository = clienteRepository ?? throw new ArgumentNullException(nameof(clienteRepository));
        }

        /// <summary>
        /// Obtiene todos los clientes registrados.
        /// </summary>
        /// <returns>Lista de clientes.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _clienteQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un cliente por su ID.
        /// </summary>
        /// <param name="id">ID del cliente a buscar.</param>
        /// <returns>Cliente correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _clienteQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un cliente con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene los clientes asociados a un restaurante.
        /// </summary>
        /// <param name="restauranteId">ID del restaurante.</param>
        /// <returns>Lista de clientes asociados al restaurante o NotFound si no existen.</returns>
        [HttpGet("restaurante/{restauranteId}")]
        public async Task<IActionResult> ObtenerPorRestaurante(int restauranteId)
        {
            try
            {
                var rs = await _clienteQueries.GetByRestaurante(restauranteId);
                if (rs == null || rs.Count == 0)
                    return NotFound($"No hay clientes para el restaurante con ID {restauranteId}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo cliente.
        /// </summary>
        /// <param name="cliente">Objeto Cliente a agregar.</param>
        /// <returns>Cliente agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Cliente cliente)
        {
            try
            {
                var rs = await _clienteRepository.Add(cliente);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.UsuarioId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar cliente: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un cliente existente.
        /// </summary>
        /// <param name="cliente">Objeto Cliente con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el cliente.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Cliente cliente)
        {
            try
            {
                var rs = await _clienteRepository.Update(cliente);
                if (!rs)
                    return NotFound($"No se encontró el cliente con ID {cliente.UsuarioId}");

                return Ok("Cliente actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar cliente: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un cliente por su ID.
        /// </summary>
        /// <param name="id">ID del cliente a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el cliente.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _clienteRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el cliente con ID {id}");

                return Ok("Cliente eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar cliente: {ex.Message}");
            }
        }
    }
}
