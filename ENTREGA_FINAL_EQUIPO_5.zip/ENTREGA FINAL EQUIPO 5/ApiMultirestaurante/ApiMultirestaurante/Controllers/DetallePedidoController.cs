﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad DetallePedido.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class DetallePedidoController : ControllerBase
    {
        private readonly IDetallePedidoQueries _detalleQueries;
        private readonly IDetallePedidoRepository _detalleRepository;

        /// <summary>
        /// Constructor del controlador DetallePedidoController.
        /// </summary>
        /// <param name="detalleQueries">Repositorio para consultas de DetallePedido.</param>
        /// <param name="detalleRepository">Repositorio para operaciones de persistencia de DetallePedido.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public DetallePedidoController(IDetallePedidoQueries detalleQueries, IDetallePedidoRepository detalleRepository)
        {
            _detalleQueries = detalleQueries ?? throw new ArgumentNullException(nameof(detalleQueries));
            _detalleRepository = detalleRepository ?? throw new ArgumentNullException(nameof(detalleRepository));
        }

        /// <summary>
        /// Obtiene todos los detalles de pedidos registrados.
        /// </summary>
        /// <returns>Lista de detalles de pedidos.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _detalleQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un detalle de pedido por su ID.
        /// </summary>
        /// <param name="id">ID del detalle de pedido a buscar.</param>
        /// <returns>Detalle de pedido correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _detalleQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un detalle pedido con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo detalle de pedido.
        /// </summary>
        /// <param name="detallePedido">Objeto DetallePedido a agregar.</param>
        /// <returns>DetallePedido agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(DetallePedido detallePedido)
        {
            try
            {
                var rs = await _detalleRepository.Add(detallePedido);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.DetalleId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar detalle de pedido: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un detalle de pedido existente.
        /// </summary>
        /// <param name="detallePedido">Objeto DetallePedido con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el detalle de pedido.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(DetallePedido detallePedido)
        {
            try
            {
                var rs = await _detalleRepository.Update(detallePedido);
                if (!rs)
                    return NotFound($"No se encontró el detalle pedido con ID {detallePedido.DetalleId}");

                return Ok("Detalle pedido actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar detalle de pedido: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un detalle de pedido por su ID.
        /// </summary>
        /// <param name="id">ID del detalle de pedido a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el detalle de pedido.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _detalleRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el detalle pedido con ID {id}");

                return Ok("Detalle pedido eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar detalle de pedido: {ex.Message}");
            }
        }
    }
}
