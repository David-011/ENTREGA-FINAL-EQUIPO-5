﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Menu.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly IMenuQueries _menuQueries;
        private readonly IMenuRepository _menuRepository;

        /// <summary>
        /// Constructor del controlador MenuController.
        /// </summary>
        /// <param name="menuQueries">Repositorio para consultas de Menu.</param>
        /// <param name="menuRepository">Repositorio para operaciones de persistencia de Menu.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public MenuController(IMenuQueries menuQueries, IMenuRepository menuRepository)
        {
            _menuQueries = menuQueries ?? throw new ArgumentNullException(nameof(menuQueries));
            _menuRepository = menuRepository ?? throw new ArgumentNullException(nameof(menuRepository));
        }

        /// <summary>
        /// Obtiene todos los menús registrados.
        /// </summary>
        /// <returns>Lista de menús.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _menuQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un menú por su ID.
        /// </summary>
        /// <param name="id">ID del menú a buscar.</param>
        /// <returns>Menú correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _menuQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un menú con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo menú.
        /// </summary>
        /// <param name="menu">Objeto Menu a agregar.</param>
        /// <returns>Menú agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Menu menu)
        {
            try
            {
                var rs = await _menuRepository.Add(menu);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.MenuId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar menú: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un menú existente.
        /// </summary>
        /// <param name="menu">Objeto Menu con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el menú.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Menu menu)
        {
            try
            {
                var rs = await _menuRepository.Update(menu);
                if (!rs)
                    return NotFound($"No se encontró el menú con ID {menu.MenuId}");

                return Ok("Menú actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar menú: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un menú por su ID.
        /// </summary>
        /// <param name="id">ID del menú a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el menú.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _menuRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el menú con ID {id}");

                return Ok("Menú eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar menú: {ex.Message}");
            }
        }
    }
}
