﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Pedido.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoQueries _pedidoQueries;
        private readonly IPedidoRepository _pedidoRepository;

        /// <summary>
        /// Constructor del controlador PedidoController.
        /// </summary>
        /// <param name="pedidoQueries">Repositorio para consultas de Pedido.</param>
        /// <param name="pedidoRepository">Repositorio para operaciones de persistencia de Pedido.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public PedidoController(IPedidoQueries pedidoQueries, IPedidoRepository pedidoRepository)
        {
            _pedidoQueries = pedidoQueries ?? throw new ArgumentNullException(nameof(pedidoQueries));
            _pedidoRepository = pedidoRepository ?? throw new ArgumentNullException(nameof(pedidoRepository));
        }

        /// <summary>
        /// Obtiene todos los pedidos registrados.
        /// </summary>
        /// <returns>Lista de pedidos.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _pedidoQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un pedido por su ID.
        /// </summary>
        /// <param name="id">ID del pedido a buscar.</param>
        /// <returns>Pedido correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _pedidoQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un pedido con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo pedido.
        /// </summary>
        /// <param name="pedido">Objeto Pedido a agregar.</param>
        /// <returns>Pedido agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Pedido pedido)
        {
            try
            {
                var rs = await _pedidoRepository.Add(pedido);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.PedidoId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar pedido: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un pedido existente.
        /// </summary>
        /// <param name="pedido">Objeto Pedido con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el pedido.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Pedido pedido)
        {
            try
            {
                var rs = await _pedidoRepository.Update(pedido);
                if (!rs)
                    return NotFound($"No se encontró el pedido con ID {pedido.PedidoId}");

                return Ok("Pedido actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar pedido: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un pedido por su ID.
        /// </summary>
        /// <param name="id">ID del pedido a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el pedido.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _pedidoRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el pedido con ID {id}");

                return Ok("Pedido eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar pedido: {ex.Message}");
            }
        }
    }
}
