﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Plato.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PlatoController : ControllerBase
    {
        private readonly IPlatoQueries _platoQueries;
        private readonly IPlatoRepository _platoRepository;

        /// <summary>
        /// Constructor del controlador PlatoController.
        /// </summary>
        /// <param name="platoQueries">Repositorio para consultas de Plato.</param>
        /// <param name="platoRepository">Repositorio para operaciones de persistencia de Plato.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public PlatoController(IPlatoQueries platoQueries, IPlatoRepository platoRepository)
        {
            _platoQueries = platoQueries ?? throw new ArgumentNullException(nameof(platoQueries));
            _platoRepository = platoRepository ?? throw new ArgumentNullException(nameof(platoRepository));
        }

        /// <summary>
        /// Obtiene todos los platos registrados.
        /// </summary>
        /// <returns>Lista de platos.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _platoQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un plato por su ID.
        /// </summary>
        /// <param name="id">ID del plato a buscar.</param>
        /// <returns>Plato correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _platoQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un plato con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo plato.
        /// </summary>
        /// <param name="plato">Objeto Plato a agregar.</param>
        /// <returns>Plato agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Plato plato)
        {
            try
            {
                var rs = await _platoRepository.Add(plato);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.PlatoId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar plato: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un plato existente.
        /// </summary>
        /// <param name="plato">Objeto Plato con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el plato.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Plato plato)
        {
            try
            {
                var rs = await _platoRepository.Update(plato);
                if (!rs)
                    return NotFound($"No se encontró el plato con ID {plato.PlatoId}");

                return Ok("Plato actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar plato: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un plato por su ID.
        /// </summary>
        /// <param name="id">ID del plato a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el plato.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _platoRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el plato con ID {id}");

                return Ok("Plato eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar plato: {ex.Message}");
            }
        }
    }
}
