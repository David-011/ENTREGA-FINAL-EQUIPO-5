﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Restaurante.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class RestauranteController : ControllerBase
    {
        private readonly IRestauranteQueries _restauranteQueries;
        private readonly IRestauranteRepository _restauranteRepository;

        /// <summary>
        /// Constructor del controlador RestauranteController.
        /// </summary>
        /// <param name="restauranteQueries">Repositorio para consultas de Restaurante.</param>
        /// <param name="restauranteRepository">Repositorio para operaciones de persistencia de Restaurante.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public RestauranteController(IRestauranteQueries restauranteQueries, IRestauranteRepository restauranteRepository)
        {
            _restauranteQueries = restauranteQueries ?? throw new ArgumentNullException(nameof(restauranteQueries));
            _restauranteRepository = restauranteRepository ?? throw new ArgumentNullException(nameof(restauranteRepository));
        }

        /// <summary>
        /// Obtiene todos los restaurantes registrados.
        /// </summary>
        /// <returns>Lista de restaurantes.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _restauranteQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un restaurante por su ID.
        /// </summary>
        /// <param name="id">ID del restaurante a buscar.</param>
        /// <returns>Restaurante correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var rs = await _restauranteQueries.GetById(id);
                if (rs == null)
                    return NotFound($"No se encontró un restaurante con ID {id}");

                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo restaurante.
        /// </summary>
        /// <param name="restaurante">Objeto Restaurante a agregar.</param>
        /// <returns>Restaurante agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Restaurante restaurante)
        {
            try
            {
                var rs = await _restauranteRepository.Add(restaurante);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = rs.UsuarioId }, rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar restaurante: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un restaurante existente.
        /// </summary>
        /// <param name="restaurante">Objeto Restaurante con datos actualizados.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el restaurante.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(Restaurante restaurante)
        {
            try
            {
                var rs = await _restauranteRepository.Update(restaurante);
                if (!rs)
                    return NotFound($"No se encontró el restaurante con ID {restaurante.UsuarioId}");

                return Ok("Restaurante actualizado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar restaurante: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un restaurante por su ID.
        /// </summary>
        /// <param name="id">ID del restaurante a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no se encontró el restaurante.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var rs = await _restauranteRepository.Delete(id);
                if (!rs)
                    return NotFound($"No se encontró el restaurante con ID {id}");

                return Ok("Restaurante eliminado correctamente");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar restaurante: {ex.Message}");
            }
        }
    }
}
