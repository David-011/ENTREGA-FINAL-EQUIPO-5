﻿using ApiMultirestaurante.Models;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiMultirestaurante.Controllers
{
    /// <summary>
    /// Controlador para gestionar operaciones sobre la entidad Usuario.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioQueries _usuarioQueries;
        private readonly IUsuarioRepository _usuarioRepository;

        /// <summary>
        /// Constructor del controlador UsuarioController.
        /// </summary>
        /// <param name="usuarioRepository">Repositorio para operaciones de persistencia de Usuario.</param>
        /// <param name="usuarioQueries">Repositorio para consultas de Usuario.</param>
        /// <exception cref="ArgumentNullException">Si alguno de los repositorios es null.</exception>
        public UsuarioController(IUsuarioRepository usuarioRepository, IUsuarioQueries usuarioQueries)
        {
            _usuarioRepository = usuarioRepository ?? throw new ArgumentNullException(nameof(usuarioRepository));
            _usuarioQueries = usuarioQueries ?? throw new ArgumentNullException(nameof(usuarioQueries));
        }

        /// <summary>
        /// Obtiene todos los usuarios registrados.
        /// </summary>
        /// <returns>Lista de usuarios.</returns>
        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var rs = await _usuarioQueries.GetAll();
                return Ok(rs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene un usuario por su ID.
        /// </summary>
        /// <param name="id">ID del usuario a buscar.</param>
        /// <returns>El usuario correspondiente o NotFound si no existe.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            try
            {
                var usuario = await _usuarioQueries.GetById(id);
                if (usuario == null)
                    return NotFound($"No se encontró el usuario con ID {id}");

                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Obtiene usuarios filtrando por tipo.
        /// </summary>
        /// <param name="tipoUsuario">Tipo de usuario ("Cliente" o "Restaurante").</param>
        /// <returns>Lista de usuarios que coinciden con el tipo especificado.</returns>
        [HttpGet("tipo/{tipoUsuario}")]
        public async Task<IActionResult> ObtenerPorTipoUsuario(string tipoUsuario)
        {
            try
            {
                var usuarios = await _usuarioQueries.GetByTipoUsuario(tipoUsuario);
                return Ok(usuarios);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        /// <summary>
        /// Agrega un nuevo usuario.
        /// </summary>
        /// <param name="usuario">Objeto Usuario a agregar.</param>
        /// <returns>Usuario agregado con su ID generado.</returns>
        [HttpPost]
        public async Task<IActionResult> Agregar(Usuario usuario)
        {
            try
            {
                var nuevo = await _usuarioRepository.Add(usuario);
                return CreatedAtAction(nameof(ObtenerPorId), new { id = nuevo.UsuarioId }, nuevo);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al agregar usuario: {ex.Message}");
            }
        }

        /// <summary>
        /// Actualiza un usuario existente.
        /// </summary>
        /// <param name="id">ID del usuario a actualizar.</param>
        /// <param name="usuario">Objeto Usuario con datos actualizados.</param>
        /// <returns>Usuario actualizado o mensaje de error si no se pudo actualizar.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(int id, Usuario usuario)
        {
            try
            {
                var existente = await _usuarioQueries.GetById(id);
                if (existente == null)
                    return NotFound($"No se encontró el usuario con ID {id}");

                usuario.UsuarioId = id;
                var actualizado = await _usuarioRepository.Update(usuario);

                if (!actualizado)
                    return BadRequest("No se pudo actualizar el usuario.");

                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al actualizar usuario: {ex.Message}");
            }
        }

        /// <summary>
        /// Elimina un usuario por su ID.
        /// </summary>
        /// <param name="id">ID del usuario a eliminar.</param>
        /// <returns>Mensaje de éxito o NotFound si no existe el usuario.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            try
            {
                var eliminado = await _usuarioRepository.Delete(id);

                if (!eliminado)
                    return NotFound($"No se encontró el usuario con ID {id}");

                return Ok($"Usuario con ID {id} eliminado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al eliminar usuario: {ex.Message}");
            }
        }
    }
}
