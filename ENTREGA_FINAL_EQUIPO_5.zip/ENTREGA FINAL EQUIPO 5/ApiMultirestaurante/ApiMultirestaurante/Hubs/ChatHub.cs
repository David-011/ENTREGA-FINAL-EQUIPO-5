﻿using Microsoft.AspNetCore.SignalR;

namespace MultiRestauranteAPI.Hubs
{
    public class ChatHub : Hub
    {

        public async Task SendMessage(int clienteId, int restauranteId, string mensaje)
        {
            string grupo = $"chat_{clienteId}_{restauranteId}";
            await Clients.Group(grupo).SendAsync("ReceiveMessage", clienteId, restauranteId, mensaje, DateTime.Now);
        }

        public override async Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            var clienteId = httpContext.Request.Query["clienteId"];
            var restauranteId = httpContext.Request.Query["restauranteId"];
            string grupo = $"chat_{clienteId}_{restauranteId}";
            await Groups.AddToGroupAsync(Context.ConnectionId, grupo);
            await base.OnConnectedAsync();
        }
    }
}
