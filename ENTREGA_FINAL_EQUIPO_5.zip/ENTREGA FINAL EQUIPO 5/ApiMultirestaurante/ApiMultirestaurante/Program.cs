﻿using ApiMultirestaurante.Repository.Implements;
using ApiMultirestaurante.Repository.Interfaces;
using Microsoft.Data.SqlClient;
using MultiRestauranteAPI.Hubs;
using System.Data;

namespace ApiMultirestaurante
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            builder.Services.AddControllers();
            builder.Services.AddSwaggerGen();


            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowBlazor", policy =>
                {
                    policy.WithOrigins(
                        "http://localhost:5008",  
                        "https://localhost:7127" 
                    )
                    .AllowAnyHeader()
                    .AllowAnyMethod();
                });
            });

            // Repositorios y queries
            builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
            builder.Services.AddScoped<IUsuarioQueries, UsuarioQueries>();

            builder.Services.AddScoped<IRestauranteRepository, RestauranteRepository>();
            builder.Services.AddScoped<IRestauranteQueries, RestauranteQueries>();

            builder.Services.AddScoped<IPlatoRepository, PlatoRepository>();
            builder.Services.AddScoped<IPlatoQueries, PlatoQueries>();

            builder.Services.AddScoped<IPedidoRepository, PedidoRepository>();
            builder.Services.AddScoped<IPedidoQueries, PedidoQueries>();

            builder.Services.AddScoped<IMenuRepository, MenuRepository>();
            builder.Services.AddScoped<IMenuQueries, MenuQueries>();

            builder.Services.AddScoped<IClienteRepository, ClienteRepository>();
            builder.Services.AddScoped<IClienteQueries, ClienteQueries>();

            builder.Services.AddScoped<IChatRepository, ChatRepository>();
            builder.Services.AddScoped<IChatQueries, ChatQueries>();

            builder.Services.AddScoped<IDetallePedidoRepository, DetallePedidoRepository>();
            builder.Services.AddScoped<IDetallePedidoQueries, DetallePedidoQueries>();



            builder.Services.AddScoped<IDbConnection>(options =>
            {
                string connectionString = builder.Configuration.GetConnectionString("sql");
                return new SqlConnection(connectionString);
            });

            var app = builder.Build();


            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseCors("AllowBlazor");

            app.UseAuthorization();
            app.MapControllers();

            app.Run();

            builder.Services.AddSignalR();

            app.MapHub<ChatHub>("/chathub");

        }
    }
}
