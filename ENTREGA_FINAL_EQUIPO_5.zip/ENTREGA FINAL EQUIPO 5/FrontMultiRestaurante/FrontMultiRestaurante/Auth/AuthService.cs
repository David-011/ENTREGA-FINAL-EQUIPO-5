﻿using Microsoft.JSInterop;
using System.Threading.Tasks;

namespace FrontMultiRestaurante.Auth
{
    public class AuthService : IAuthService
    {
        private readonly IJSRuntime _js;
        private const string USER_KEY = "mr_user";

        public AuthService(IJSRuntime js)
        {
            _js = js;
        }

        /// <summary>
        /// Simula login de usuario. Guarda el nombre en localStorage.
        /// Más adelante se puede reemplazar con un login real vía API.
        /// </summary>
        public async Task<bool> Login(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                return false;

            // Extrae nombre de usuario del email
            var username = email.Split('@')[0];

            // Guardar en localStorage
            await _js.InvokeVoidAsync("localStorage.setItem", USER_KEY, username);
            return true;
        }

        /// <summary>
        /// Logout: elimina usuario de localStorage
        /// </summary>
        public async Task Logout()
        {
            await _js.InvokeVoidAsync("localStorage.removeItem", USER_KEY);
        }

        /// <summary>
        /// Verifica si hay usuario logueado
        /// </summary>
        public async Task<bool> IsLoggedIn()
        {
            var user = await _js.InvokeAsync<string?>("localStorage.getItem", USER_KEY);
            return !string.IsNullOrWhiteSpace(user);
        }

        /// <summary>
        /// Obtiene el nombre del usuario logueado
        /// </summary>
        public async Task<string?> GetUserName()
        {
            return await _js.InvokeAsync<string?>("localStorage.getItem", USER_KEY);
        }
    }
}
