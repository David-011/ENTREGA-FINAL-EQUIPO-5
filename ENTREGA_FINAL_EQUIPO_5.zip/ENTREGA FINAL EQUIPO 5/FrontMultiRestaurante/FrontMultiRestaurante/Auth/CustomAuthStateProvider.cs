﻿using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;
using Microsoft.JSInterop;
using FrontMultiRestaurante.Models; 

namespace FrontMultiRestaurante.Auth
{
    public class CustomAuthStateProvider : AuthenticationStateProvider
    {
        private readonly IJSRuntime _js;
        private readonly IAuthService _authService;
        private const string USER_KEY = "mr_user";
        private readonly ClaimsPrincipal _anonymous = new(new ClaimsIdentity());

        public CustomAuthStateProvider(IJSRuntime js, IAuthService authService)
        {
            _js = js;
            _authService = authService;
        }

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var username = await _js.InvokeAsync<string?>("localStorage.getItem", USER_KEY);

            if (string.IsNullOrWhiteSpace(username))
                return new AuthenticationState(_anonymous);

            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username)
            }, "FakeAuth");

            var user = new ClaimsPrincipal(identity);
            return new AuthenticationState(user);
        }

        public async Task MarkUserAsAuthenticated(string username)
        {
            // Guardar en localStorage
            await _js.InvokeVoidAsync("localStorage.setItem", USER_KEY, username);

            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username)
            }, "FakeAuth");

            var user = new ClaimsPrincipal(identity);
            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(user)));
        }

        public async Task MarkUserAsLoggedOut()
        {
            // Eliminar de localStorage
            await _js.InvokeVoidAsync("localStorage.removeItem", USER_KEY);

            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(_anonymous)));
        }
    }
}
