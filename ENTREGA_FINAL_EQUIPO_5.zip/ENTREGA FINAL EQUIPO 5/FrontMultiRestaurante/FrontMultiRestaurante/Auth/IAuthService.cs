﻿namespace FrontMultiRestaurante.Auth
{
    public interface IAuthService
    {
        Task<bool> Login(string email, string password);
        Task Logout();
        Task<bool> IsLoggedIn();
        Task<string?> GetUserName();
    }
}

