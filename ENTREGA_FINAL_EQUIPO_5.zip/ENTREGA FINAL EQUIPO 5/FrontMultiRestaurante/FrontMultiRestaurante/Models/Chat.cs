﻿namespace FrontMultiRestaurante.Models
{
    public class Chat
    {
        public int ChatId { get; set; }
        public int ClienteId { get; set; }
        public int RestauranteId { get; set; }
        public string? Mensaje { get; set; }
        public DateTime? Fecha { get; set; }
    }
}
