﻿namespace FrontMultiRestaurante.Models
{
    public class ChatMessage
    {
        public string Emisor { get; set; } = "";
        public string Mensaje { get; set; } = "";
        public DateTime Fecha { get; set; }
    }
}
