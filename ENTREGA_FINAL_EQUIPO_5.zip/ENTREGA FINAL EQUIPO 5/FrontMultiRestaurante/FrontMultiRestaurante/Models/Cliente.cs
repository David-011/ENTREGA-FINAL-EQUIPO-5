﻿namespace FrontMultiRestaurante.Models
{
    public class Cliente
    {
        public int UsuarioId { get; set; }
    }
}
