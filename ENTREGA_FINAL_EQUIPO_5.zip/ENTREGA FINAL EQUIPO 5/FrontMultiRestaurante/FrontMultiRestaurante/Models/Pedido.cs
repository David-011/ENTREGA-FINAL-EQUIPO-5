﻿namespace FrontMultiRestaurante.Models
{
    public class Pedido
    {
        public int PedidoId { get; set; }
        public int ClienteId { get; set; }
        public int RestauranteId { get; set; }
        public DateTime FechaPedido { get; set; }
        public string? Estado { get; set; }
        public string? DireccionEnvio { get; set; }
    }
}
