﻿namespace FrontMultiRestaurante.Models
{
    public class Plato
    {
        public int PlatoId { get; set; }
        public int MenuId { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string? Descripcion { get; set; }
        public decimal Precio { get; set; }
    }
}
