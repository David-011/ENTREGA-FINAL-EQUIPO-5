﻿namespace FrontMultiRestaurante.Models
{
    public class Usuario
    {
        public int UsuarioId { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Contraseña { get; set; } = string.Empty;
        public string? Telefono { get; set; }
        public string TipoUsuario { get; set; } = string.Empty;
    }
}
