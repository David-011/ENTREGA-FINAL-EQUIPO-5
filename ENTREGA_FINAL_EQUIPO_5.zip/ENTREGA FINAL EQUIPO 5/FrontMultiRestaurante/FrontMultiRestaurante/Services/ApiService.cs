﻿using System.Net.Http.Json;
using FrontMultiRestaurante.Models;

namespace FrontMultiRestaurante.Services
{
    /// <summary>
    /// Interfaz para consumir la API del sistema Multirestaurante.
    /// </summary>
    public interface IApiService
    {
        // Restaurante 
        Task<List<Restaurante>> GetRestaurantesAsync();
        Task<Restaurante?> GetRestauranteByIdAsync(int id);

        // Plato 
        Task<List<Plato>> GetPlatosAsync();
        Task<Plato?> GetPlatoByIdAsync(int id);
        Task<bool> CreatePlatoAsync(Plato plato);
        Task<bool> UpdatePlatoAsync(int id, Plato plato);
        Task<bool> DeletePlatoAsync(int id);

        //  Menú 
        Task<List<Menu>> GetMenusAsync();
        Task<Menu?> GetMenuByIdAsync(int id);
        Task<bool> CreateMenuAsync(Menu menu);
        Task<bool> UpdateMenuAsync(int id, Menu menu);
        Task<bool> DeleteMenuAsync(int id);

        // Pedido 
        Task<List<Pedido>> GetPedidosAsync();
        Task<Pedido?> GetPedidoByIdAsync(int id);
        Task<bool> CreatePedidoAsync(Pedido pedido);
        Task<bool> UpdatePedidoAsync(int id, Pedido pedido);
        Task<bool> DeletePedidoAsync(int id);

        // Detalle Pedido 
        Task<List<DetallePedido>> GetDetallePedidosAsync();
        Task<DetallePedido?> GetDetallePedidoByIdAsync(int id);
        Task<bool> CreateDetallePedidoAsync(DetallePedido detalle);
        Task<bool> UpdateDetallePedidoAsync(int id, DetallePedido detalle);
        Task<bool> DeleteDetallePedidoAsync(int id);

        // Cliente 
        Task<List<Cliente>> GetClientesAsync();
        Task<Cliente?> GetClienteByIdAsync(int id);
        Task<bool> CreateClienteAsync(Cliente cliente);
        Task<bool> UpdateClienteAsync(int id, Cliente cliente);
        Task<bool> DeleteClienteAsync(int id);
        Task<List<Cliente>> GetClientesByRestauranteAsync(int restauranteId);

        //  Chat 
        Task<List<Chat>> GetChatsAsync();
        Task<Chat?> GetChatByIdAsync(int id);
        Task<bool> CreateChatAsync(Chat chat);
        Task<bool> UpdateChatAsync(int id, Chat chat);
        Task<bool> DeleteChatAsync(int id);
        Task<List<Chat>> GetChatsByClienteAsync(int clienteId);
        Task<List<Chat>> GetChatsByRestauranteAsync(int restauranteId);
        Task<List<Chat>> GetChatsByClienteYRestauranteAsync(int clienteId, int restauranteId);
    }

    /// <summary>
    /// Implementación de <see cref="IApiService"/> que utiliza <see cref="HttpClient"/> para comunicarse con la API.
    /// </summary>
    public class ApiService : IApiService
    {
        private readonly HttpClient _http;
        private const string API_BASE = "http://localhost:5294/api";

        /// <summary>
        /// Constructor que recibe <see cref="HttpClient"/> para consumir la API.
        /// </summary>
        /// <param name="http">HttpClient configurado con la URL base.</param>
        public ApiService(HttpClient http)
        {
            _http = http;
        }

        //  Restaurante
        public async Task<List<Restaurante>> GetRestaurantesAsync() =>
            await _http.GetFromJsonAsync<List<Restaurante>>($"{API_BASE}/Restaurante") ?? new List<Restaurante>();

        public async Task<Restaurante?> GetRestauranteByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Restaurante>($"{API_BASE}/Restaurante/{id}");

        // Plato 
        public async Task<List<Plato>> GetPlatosAsync() =>
            await _http.GetFromJsonAsync<List<Plato>>($"{API_BASE}/Plato") ?? new List<Plato>();

        public async Task<Plato?> GetPlatoByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Plato>($"{API_BASE}/Plato/{id}");

        public async Task<bool> CreatePlatoAsync(Plato plato) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/Plato", plato)).IsSuccessStatusCode;

        public async Task<bool> UpdatePlatoAsync(int id, Plato plato) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/Plato/{id}", plato)).IsSuccessStatusCode;

        public async Task<bool> DeletePlatoAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/Plato/{id}")).IsSuccessStatusCode;

        //  Menú 
        public async Task<List<Menu>> GetMenusAsync() =>
            await _http.GetFromJsonAsync<List<Menu>>($"{API_BASE}/Menu") ?? new List<Menu>();

        public async Task<Menu?> GetMenuByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Menu>($"{API_BASE}/Menu/{id}");

        public async Task<bool> CreateMenuAsync(Menu menu) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/Menu", menu)).IsSuccessStatusCode;

        public async Task<bool> UpdateMenuAsync(int id, Menu menu) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/Menu/{id}", menu)).IsSuccessStatusCode;

        public async Task<bool> DeleteMenuAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/Menu/{id}")).IsSuccessStatusCode;

        //  Pedido 
        public async Task<List<Pedido>> GetPedidosAsync() =>
            await _http.GetFromJsonAsync<List<Pedido>>($"{API_BASE}/Pedido") ?? new List<Pedido>();

        public async Task<Pedido?> GetPedidoByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Pedido>($"{API_BASE}/Pedido/{id}");

        public async Task<bool> CreatePedidoAsync(Pedido pedido) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/Pedido", pedido)).IsSuccessStatusCode;

        public async Task<bool> UpdatePedidoAsync(int id, Pedido pedido) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/Pedido/{id}", pedido)).IsSuccessStatusCode;

        public async Task<bool> DeletePedidoAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/Pedido/{id}")).IsSuccessStatusCode;

        // Detalle Pedido 
        public async Task<List<DetallePedido>> GetDetallePedidosAsync() =>
            await _http.GetFromJsonAsync<List<DetallePedido>>($"{API_BASE}/DetallePedido") ?? new List<DetallePedido>();

        public async Task<DetallePedido?> GetDetallePedidoByIdAsync(int id) =>
            await _http.GetFromJsonAsync<DetallePedido>($"{API_BASE}/DetallePedido/{id}");

        public async Task<bool> CreateDetallePedidoAsync(DetallePedido detalle) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/DetallePedido", detalle)).IsSuccessStatusCode;

        public async Task<bool> UpdateDetallePedidoAsync(int id, DetallePedido detalle) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/DetallePedido/{id}", detalle)).IsSuccessStatusCode;

        public async Task<bool> DeleteDetallePedidoAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/DetallePedido/{id}")).IsSuccessStatusCode;

        // Cliente 
        public async Task<List<Cliente>> GetClientesAsync() =>
            await _http.GetFromJsonAsync<List<Cliente>>($"{API_BASE}/Cliente") ?? new List<Cliente>();

        public async Task<Cliente?> GetClienteByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Cliente>($"{API_BASE}/Cliente/{id}");

        public async Task<bool> CreateClienteAsync(Cliente cliente) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/Cliente", cliente)).IsSuccessStatusCode;

        public async Task<bool> UpdateClienteAsync(int id, Cliente cliente) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/Cliente/{id}", cliente)).IsSuccessStatusCode;

        public async Task<bool> DeleteClienteAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/Cliente/{id}")).IsSuccessStatusCode;

        public async Task<List<Cliente>> GetClientesByRestauranteAsync(int restauranteId) =>
            await _http.GetFromJsonAsync<List<Cliente>>($"{API_BASE}/Cliente/restaurante/{restauranteId}") ?? new List<Cliente>();

        //  Chat 
        public async Task<List<Chat>> GetChatsAsync() =>
            await _http.GetFromJsonAsync<List<Chat>>($"{API_BASE}/Chat") ?? new List<Chat>();

        public async Task<Chat?> GetChatByIdAsync(int id) =>
            await _http.GetFromJsonAsync<Chat>($"{API_BASE}/Chat/{id}");

        public async Task<bool> CreateChatAsync(Chat chat) =>
            (await _http.PostAsJsonAsync($"{API_BASE}/Chat", chat)).IsSuccessStatusCode;

        public async Task<bool> UpdateChatAsync(int id, Chat chat) =>
            (await _http.PutAsJsonAsync($"{API_BASE}/Chat/{id}", chat)).IsSuccessStatusCode;

        public async Task<bool> DeleteChatAsync(int id) =>
            (await _http.DeleteAsync($"{API_BASE}/Chat/{id}")).IsSuccessStatusCode;

        public async Task<List<Chat>> GetChatsByClienteAsync(int clienteId) =>
            await _http.GetFromJsonAsync<List<Chat>>($"{API_BASE}/Chat/cliente/{clienteId}") ?? new List<Chat>();

        public async Task<List<Chat>> GetChatsByRestauranteAsync(int restauranteId) =>
            await _http.GetFromJsonAsync<List<Chat>>($"{API_BASE}/Chat/restaurante/{restauranteId}") ?? new List<Chat>();

        public async Task<List<Chat>> GetChatsByClienteYRestauranteAsync(int clienteId, int restauranteId) =>
            await _http.GetFromJsonAsync<List<Chat>>($"{API_BASE}/Chat/{clienteId}/{restauranteId}") ?? new List<Chat>();
    }
}
